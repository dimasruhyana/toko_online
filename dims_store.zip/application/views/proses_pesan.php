<div class="container-fluid">	
		
		<div class="alert alert-success">
			<a href="<?=  base_url('welcome/index'); ?>"><h4 align="middle">Selamat, Pesanan anda Berhail Diproses</h3>
		</div>

</div>